#!/bin/bash

rm temperature.log
rm ldr.log

for LENG in c asm
do
	for ARCH in lena.203x203.bmp lena.512x512.bmp lena.1023x767.bmp marilyn.203x203.bmp marilyn.512x512.bmp marilyn.1023x767.bmp
	do
		for j in {1..5}
		do
			./tp2 temperature -i $LENG $ARCH >> temperature.log
		done
	done
done

for LENG in c asm
do
	for ARCH in lena.203x203.bmp lena.512x512.bmp lena.1023x767.bmp marilyn.203x203.bmp marilyn.512x512.bmp marilyn.1023x767.bmp
	do
		for j in {1..5}
		do
			./tp2 ldr -i $LENG $ARCH 200 >> ldr.log
		done
	done
done